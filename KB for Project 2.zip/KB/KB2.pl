food(2). %initial food level
materials(3). %initial materials level
energy(1). %initial energy level
build1(2,2,1). %build1 requires 2 food, 2 materials, 1 energy
build2(3,2,1). %build2 requires 2 food, 2 materials, 1 energy