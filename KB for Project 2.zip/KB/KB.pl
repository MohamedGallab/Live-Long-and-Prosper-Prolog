food(1). %initial food level
materials(0). %initial materials level
energy(2). %initial energy level
build1(1,2,1). %build1 requires 1 food, 2 materials, 1 energy
build2(4,1,2). %build2 requires 4 food, 1 materials, 2 energy